import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { validationResult } from 'express-validator';
import { pool } from '../database';

export const getUsers = async (req: Request, res: Response) => {
    const [rows] = await pool.query('SELECT * FROM users');
    res.render('users/index', { users: rows });
};

export const addUserForm = (req: Request, res: Response) => {
    res.render('users/form', { errors: [], formData: {} });
};

export const saveUser = async (req: Request, res: Response) => {
    const errors = validationResult(req);
    const { name, email, password, confirmPassword, role, active } = req.body;

    if (!errors.isEmpty()) {
        return res.render('users/form', { errors: errors.array(), formData: req.body });
    }

    if (password !== confirmPassword) {
        return res.render('users/form', { errors: [{ msg: 'As senhas não coincidem' }], formData: req.body });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    await pool.query('INSERT INTO users (name, email, password, role, active) VALUES (?, ?, ?, ?, ?)', [
        name,
        email,
        hashedPassword,
        role,
        active ? 1 : 0,
    ]);

    res.redirect('/users');
};

export const deleteUser = async (req: Request, res: Response) => {
    const { id } = req.params;
    await pool.query('DELETE FROM users WHERE id = ?', [id]);
    res.redirect('/users');
};
