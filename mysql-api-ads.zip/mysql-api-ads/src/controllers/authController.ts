import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import { pool } from '../database';

export const loginForm = (req: Request, res: Response) => {
    res.render('login', { errorMessage: null });
};

export const login = async (req: Request, res: Response) => {
    const { email, password } = req.body;

    const [rows]: any = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return res.render('login', { errorMessage: 'Credenciais inválidas.' });
    }

    req.session.user = user;
    res.redirect('/users');
};

export const logout = (req: Request, res: Response) => {
    req.session.destroy((err) => {
        if (err) {
            return res.status(500).send('Erro ao encerrar a sessão');
        }
        res.redirect('/login');
    });
};
