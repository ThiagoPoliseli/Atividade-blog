import { Router } from 'express';
import { getUsers, addUserForm, saveUser, deleteUser } from '../controllers/userController';
import { body } from 'express-validator';

const router = Router();

router.get('/', getUsers);
router.get('/add', addUserForm);
router.post('/',
    [
        body('name').notEmpty().withMessage('O nome é obrigatório'),
        body('email').isEmail().withMessage('Email inválido'),
        body('password').isLength({ min: 5 }).withMessage('A senha deve ter no mínimo 5 caracteres'),
    ],
    saveUser
);
router.post('/:id/delete', deleteUser);

export default router;
